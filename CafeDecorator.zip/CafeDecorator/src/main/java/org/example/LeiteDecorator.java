package org.example;

// File: LeiteDecorator.java

public class LeiteDecorator extends AdicionalDecorator {
    public LeiteDecorator(cafe cafeDecorado) {
        super(cafeDecorado);
    }

    @Override
    public double CalcularCusto() {
        return super.cafeDecorado.CalcularCusto() + 2.0;
    }

    @Override
    public String getDescricao() {
        return super.cafeDecorado.getDescricao() + ", com Leite";
    }
}