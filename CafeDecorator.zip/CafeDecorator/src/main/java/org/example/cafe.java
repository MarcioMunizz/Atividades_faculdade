package org.example;

public interface cafe {
    double CalcularCusto();
    String getDescricao();
}
