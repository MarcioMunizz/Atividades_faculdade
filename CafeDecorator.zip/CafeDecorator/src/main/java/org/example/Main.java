package org.example;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Demonstrando o padrão de projeto Decorator para pedidos de café.\n");

        // Criando um café simples
        cafe meuCafe = new CafeSimples();
        System.out.println("Pedido: " + meuCafe.getDescricao());
        System.out.println("Custo Total: $" + meuCafe.CalcularCusto());

        System.out.println("---");

        // Decorator o café com leite
        cafe cafeComLeite = new LeiteDecorator(meuCafe);
        System.out.println("Pedido: " + cafeComLeite.getDescricao());
        System.out.println("Custo Total: $" + cafeComLeite.CalcularCusto());

        System.out.println("---");

        // Decorator o café (que já tem leite) com açúcar
        cafe cafeComLeiteEAcucar = new AcucarDecorator(cafeComLeite);
        System.out.println("Pedido: " + cafeComLeiteEAcucar.getDescricao());
        System.out.println("Custo Total: $" + cafeComLeiteEAcucar.CalcularCusto());
    }
}