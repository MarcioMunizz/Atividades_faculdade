package org.example;

// File: AcucarDecorator.java

public class AcucarDecorator extends AdicionalDecorator {
    public AcucarDecorator(cafe cafeDecorado) {
        super(cafeDecorado);
    }

    @Override
    public double CalcularCusto() {
        return super.cafeDecorado.CalcularCusto() + 0.5;
    }

    @Override
    public String getDescricao() {
        return super.cafeDecorado.getDescricao() + ", com Açúcar";
    }
}