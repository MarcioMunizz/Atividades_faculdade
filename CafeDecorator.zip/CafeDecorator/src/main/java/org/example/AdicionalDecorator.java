package org.example;

public abstract class AdicionalDecorator implements cafe {
    protected cafe cafeDecorado;

    public AdicionalDecorator(cafe cafeDecorado) {
        this.cafeDecorado = cafeDecorado;
    }

    // Os métodos são sobrescritos nas classes concretas
    @Override
    public abstract double CalcularCusto();

    @Override
    public abstract String getDescricao();
}