package org.example;

public class CafeSimples implements cafe{
    @Override
    public double CalcularCusto() {
        return 5.0;
    }

    @Override
    public String getDescricao() {
        return "Cafe Simples";
    }
}
